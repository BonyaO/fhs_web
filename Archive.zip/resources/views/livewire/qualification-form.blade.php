<div>
    {{ $this->table }}
    <x-filament-actions::modals />
</div>
