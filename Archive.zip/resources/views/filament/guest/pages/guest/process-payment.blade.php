<x-filament-panels::page>
    <x-filament::section>
        @livewire('payment-form')
    </x-filament::section>
</x-filament-panels::page>
