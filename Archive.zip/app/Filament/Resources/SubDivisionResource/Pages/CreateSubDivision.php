<?php

namespace App\Filament\Resources\SubDivisionResource\Pages;

use App\Filament\Resources\SubDivisionResource;
use Filament\Resources\Pages\CreateRecord;

class CreateSubDivision extends CreateRecord
{
    protected static string $resource = SubDivisionResource::class;
}
