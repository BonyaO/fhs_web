<?php

namespace App\Filament\Resources\DepartmentOptionResource\Pages;

use App\Filament\Resources\DepartmentOptionResource;
use Filament\Resources\Pages\CreateRecord;

class CreateDepartmentOption extends CreateRecord
{
    protected static string $resource = DepartmentOptionResource::class;
}
