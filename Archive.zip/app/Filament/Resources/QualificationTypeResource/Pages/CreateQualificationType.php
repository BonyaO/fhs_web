<?php

namespace App\Filament\Resources\QualificationTypeResource\Pages;

use App\Filament\Resources\QualificationTypeResource;
use Filament\Resources\Pages\CreateRecord;

class CreateQualificationType extends CreateRecord
{
    protected static string $resource = QualificationTypeResource::class;
}
