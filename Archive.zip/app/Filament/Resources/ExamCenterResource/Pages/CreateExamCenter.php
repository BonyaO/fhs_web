<?php

namespace App\Filament\Resources\ExamCenterResource\Pages;

use App\Filament\Resources\ExamCenterResource;
use Filament\Resources\Pages\CreateRecord;

class CreateExamCenter extends CreateRecord
{
    protected static string $resource = ExamCenterResource::class;
}
