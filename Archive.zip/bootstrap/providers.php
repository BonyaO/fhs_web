<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\Filament\AppPanelProvider::class,
    App\Providers\Filament\ApplicantPanelProvider::class,
    App\Providers\Filament\GuestPanelProvider::class,
];
